from django.urls import path
from . import views

app_name = 'inventory'

urlpatterns = [
    path('', views.inventory_view, name='index'),
    path('purchase-orders/', views.purchase_order_list, name='purchase_orders'),
]
