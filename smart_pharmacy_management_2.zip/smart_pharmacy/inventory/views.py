from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.utils import timezone
from datetime import timedelta
from pharmacy.models import Medicine, MedicineBatch
from .models import Stock, PurchaseOrder, StockReturn


@login_required
def inventory_view(request):
    medicines = Medicine.objects.filter(is_active=True).prefetch_related('batches')
    today = timezone.now().date()

    # Low stock
    low_stock = [m for m in medicines if m.is_low_stock]

    # Expiring soon
    expiring_batches = MedicineBatch.objects.filter(
        expiry_date__lte=today + timedelta(days=90),
        expiry_date__gte=today,
        quantity__gt=0
    ).select_related('medicine').order_by('expiry_date')

    # Expired
    expired_batches = MedicineBatch.objects.filter(
        expiry_date__lt=today, quantity__gt=0
    ).select_related('medicine')

    return render(request, 'inventory.html', {
        'medicines': medicines,
        'low_stock': low_stock,
        'expiring_batches': expiring_batches,
        'expired_batches': expired_batches,
    })


@login_required
def purchase_order_list(request):
    orders = PurchaseOrder.objects.select_related('supplier').order_by('-created_at')
    return render(request, 'purchase_order_list.html', {'orders': orders})
