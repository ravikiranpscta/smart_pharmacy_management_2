-- ============================================================
-- Smart Pharmacy Management System – MySQL Schema
-- Run AFTER Django migrations for reference / manual setup
-- ============================================================

CREATE DATABASE IF NOT EXISTS smart_pharmacy
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE smart_pharmacy;

-- Useful views on top of Django ORM tables

-- ── Current stock per medicine ──────────────────────────────
CREATE OR REPLACE VIEW v_medicine_stock AS
SELECT
    m.id             AS medicine_id,
    m.name           AS medicine_name,
    m.strength,
    c.name           AS category,
    COALESCE(SUM(CASE WHEN b.expiry_date >= CURDATE() THEN b.quantity ELSE 0 END), 0) AS available_stock,
    COALESCE(SUM(b.quantity), 0)                                                        AS total_stock,
    MIN(b.expiry_date)                                                                   AS nearest_expiry
FROM pharmacy_medicine m
LEFT JOIN pharmacy_category c ON c.id = m.category_id
LEFT JOIN pharmacy_medicinebatch b ON b.medicine_id = m.id
WHERE m.is_active = 1
GROUP BY m.id, m.name, m.strength, c.name;

-- ── Daily sales summary ─────────────────────────────────────
CREATE OR REPLACE VIEW v_daily_sales AS
SELECT
    DATE(created_at)           AS sale_date,
    COUNT(*)                   AS bill_count,
    SUM(subtotal)              AS subtotal,
    SUM(discount_amount)       AS total_discount,
    SUM(gst_amount)            AS total_gst,
    SUM(total_amount)          AS total_sales
FROM billing_bill
WHERE payment_status = 'paid'
GROUP BY DATE(created_at)
ORDER BY sale_date DESC;

-- ── Expiring medicines ──────────────────────────────────────
CREATE OR REPLACE VIEW v_expiring_medicines AS
SELECT
    m.name AS medicine_name,
    b.batch_number,
    b.quantity,
    b.expiry_date,
    DATEDIFF(b.expiry_date, CURDATE()) AS days_to_expiry
FROM pharmacy_medicinebatch b
JOIN pharmacy_medicine m ON m.id = b.medicine_id
WHERE b.expiry_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 90 DAY)
  AND b.quantity > 0
ORDER BY b.expiry_date;

-- ── Stored procedure: get low stock medicines ───────────────
DELIMITER $$
CREATE PROCEDURE IF NOT EXISTS sp_low_stock(IN threshold INT)
BEGIN
    SELECT
        m.id,
        m.name,
        m.strength,
        COALESCE(SUM(CASE WHEN b.expiry_date >= CURDATE() THEN b.quantity ELSE 0 END), 0) AS stock
    FROM pharmacy_medicine m
    LEFT JOIN pharmacy_medicinebatch b ON b.medicine_id = m.id
    WHERE m.is_active = 1
    GROUP BY m.id, m.name, m.strength
    HAVING stock < threshold
    ORDER BY stock ASC;
END$$
DELIMITER ;

-- ── Trigger: update customer total purchases after bill ─────
DELIMITER $$
CREATE TRIGGER IF NOT EXISTS trg_update_customer_totals
AFTER UPDATE ON billing_bill
FOR EACH ROW
BEGIN
    IF NEW.payment_status = 'paid' AND OLD.payment_status != 'paid' AND NEW.customer_id IS NOT NULL THEN
        UPDATE customers_customer
        SET total_purchases = total_purchases + NEW.total_amount,
            loyalty_points  = loyalty_points + FLOOR(NEW.total_amount / 100)
        WHERE id = NEW.customer_id;
    END IF;
END$$
DELIMITER ;
