from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
from django.conf import settings


@login_required
def initiate_razorpay(request):
    """Create Razorpay order."""
    import razorpay
    amount = request.POST.get('amount')
    client = razorpay.Client(auth=(settings.RAZORPAY_KEY_ID, settings.RAZORPAY_KEY_SECRET))
    order = client.order.create({
        'amount': int(float(amount) * 100),  # in paise
        'currency': 'INR',
        'payment_capture': 1,
    })
    return JsonResponse({
        'order_id': order['id'],
        'key': settings.RAZORPAY_KEY_ID,
        'amount': amount,
    })


@login_required
def verify_payment(request):
    """Verify Razorpay payment signature."""
    import razorpay
    client = razorpay.Client(auth=(settings.RAZORPAY_KEY_ID, settings.RAZORPAY_KEY_SECRET))
    params = {
        'razorpay_order_id': request.POST.get('razorpay_order_id'),
        'razorpay_payment_id': request.POST.get('razorpay_payment_id'),
        'razorpay_signature': request.POST.get('razorpay_signature'),
    }
    try:
        client.utility.verify_payment_signature(params)
        return JsonResponse({'success': True})
    except Exception:
        return JsonResponse({'success': False, 'error': 'Invalid signature'}, status=400)
