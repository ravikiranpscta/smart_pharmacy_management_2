from django.urls import path
from . import views

app_name = 'payments'

urlpatterns = [
    path('razorpay/initiate/', views.initiate_razorpay, name='razorpay_initiate'),
    path('razorpay/verify/', views.verify_payment, name='razorpay_verify'),
]
