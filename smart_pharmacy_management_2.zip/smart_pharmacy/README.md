# 💊 Smart Pharmacy Management System

A full-featured pharmacy management system built with **Django 4.2** + **Flask AI API**.

---

## 🌟 Features

| Module | Capabilities |
|--------|-------------|
| **Dashboard** | Live sales stats, charts, alerts |
| **Billing / POS** | Fast medicine search, cart, GST, PDF invoice |
| **Medicines** | Add, edit, batch management, barcode |
| **Inventory** | Stock levels, expiry alerts, low-stock warnings |
| **Customers** | Profiles, loyalty points, purchase history |
| **Suppliers** | Supplier management, credit tracking |
| **Prescriptions** | Upload & manage prescription images |
| **Reports** | Daily / Weekly / Monthly / Yearly sales |
| **Analytics** | Interactive charts, top medicines |
| **Payments** | Cash, UPI, Card, Razorpay, Stripe |
| **Flask AI API** | Medicine recommendations, drug interaction checker |

---

## 📁 Project Structure

```
smart_pharmacy/
├── config/          # Django settings, URLs, middleware
├── accounts/        # Custom user model, auth, OTP
├── dashboard/       # Dashboard with live stats & charts
├── pharmacy/        # Medicine & batch management
├── billing/         # POS billing, PDF invoice
├── inventory/       # Stock, expiry, purchase orders
├── customers/       # Customer profiles, loyalty
├── suppliers/       # Supplier management
├── prescriptions/   # Prescription uploads
├── reports/         # Sales reports
├── analytics/       # Charts & analytics
├── payments/        # Razorpay, Stripe, UPI
├── flask_api/       # AI: recommendations, interactions
├── templates/       # HTML templates
├── static/          # CSS, JS, images
└── database/        # SQL schema, views, triggers
```

---

## ⚡ QUICK SETUP & EXECUTION STEPS

### Step 1 — Prerequisites

Make sure you have these installed:

```bash
python --version     # Python 3.10 or 3.11 recommended
pip --version
mysql --version      # MySQL 8.0+ (or use SQLite for quick start)
redis-server         # Optional: only needed for Celery/background tasks
```

---

### Step 2 — Clone / Download the Project

```bash
git clone https://github.com/yourname/smart_pharmacy.git
cd smart_pharmacy
```

---

### Step 3 — Create Virtual Environment

```bash
# Create venv
python -m venv venv

# Activate (Linux / macOS)
source venv/bin/activate

# Activate (Windows)
venv\Scripts\activate
```

---

### Step 4 — Install Dependencies

```bash
pip install -r requirements.txt
```

> **Note:** If `mysqlclient` fails to install, try:
> ```bash
> # Ubuntu/Debian
> sudo apt install python3-dev default-libmysqlclient-dev build-essential
> pip install mysqlclient
>
> # macOS
> brew install mysql-client
> pip install mysqlclient
>
> # Windows — use pymysql instead:
> pip install pymysql
> ```

---

### Step 5 — Configure Environment Variables

Copy the example env file and fill in your values:

```bash
cp .env .env.local   # or just edit .env directly
```

Edit `.env`:

```ini
DEBUG=True
SECRET_KEY=your-very-long-random-secret-key-here

# ─── Option A: SQLite (easiest for local dev) ───
DB_ENGINE=django.db.backends.sqlite3
DB_NAME=db.sqlite3
DB_USER=
DB_PASSWORD=
DB_HOST=
DB_PORT=

# ─── Option B: MySQL ────────────────────────────
# DB_ENGINE=django.db.backends.mysql
# DB_NAME=smart_pharmacy
# DB_USER=root
# DB_PASSWORD=yourpassword
# DB_HOST=localhost
# DB_PORT=3306

# Email (optional for OTP/notifications)
EMAIL_HOST_USER=your@gmail.com
EMAIL_HOST_PASSWORD=your_gmail_app_password

# Payments (optional)
RAZORPAY_KEY_ID=
RAZORPAY_KEY_SECRET=
STRIPE_PUBLIC_KEY=
STRIPE_SECRET_KEY=
```

---

### Step 6 — Create MySQL Database (skip if using SQLite)

```bash
mysql -u root -p
```

```sql
CREATE DATABASE smart_pharmacy CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
EXIT;
```

---

### Step 7 — Run Django Migrations

```bash
python manage.py makemigrations accounts
python manage.py makemigrations pharmacy
python manage.py makemigrations customers
python manage.py makemigrations suppliers
python manage.py makemigrations billing
python manage.py makemigrations inventory
python manage.py makemigrations prescriptions
python manage.py makemigrations
python manage.py migrate
```

---

### Step 8 — Create Superuser (Admin)

```bash
python manage.py createsuperuser
```

Enter username, email, and password when prompted.

---

### Step 9 — Collect Static Files

```bash
python manage.py collectstatic --noinput
```

---

### Step 10 — Load Sample Data (Optional)

```bash
python manage.py shell
```

```python
from pharmacy.models import Category, Manufacturer

# Create some categories
for name in ['Antibiotics', 'Analgesics', 'Antacids', 'Vitamins', 'Cardiac', 'Diabetic', 'Derma']:
    Category.objects.get_or_create(name=name)

from accounts.models import User
u = User.objects.first()
u.role = 'admin'
u.pharmacy_name = 'My Pharmacy'
u.save()
exit()
```

---

### Step 11 — Start the Django Server

```bash
python manage.py runserver
```

Open your browser: **http://127.0.0.1:8000**

- **Login:** http://127.0.0.1:8000/accounts/login/
- **Admin:** http://127.0.0.1:8000/admin/
- **Dashboard:** http://127.0.0.1:8000/dashboard/

---

### Step 12 — Start Flask AI API (Optional, separate terminal)

```bash
# In a new terminal, activate venv first
source venv/bin/activate

# Install Flask requirements
pip install -r flask_api/requirements.txt

# Run Flask
python flask_api/app.py
```

Flask runs on: **http://127.0.0.1:5000**

Test it:
```bash
curl http://localhost:5000/health
curl -X POST http://localhost:5000/api/recommend \
     -H "Content-Type: application/json" \
     -d '{"symptoms": ["fever", "headache"]}'
```

---

## 🗄️ Database Schema & SQL

Run the SQL views and stored procedures (after migrations):

```bash
mysql -u root -p smart_pharmacy < database/schema.sql
```

This creates useful views:
- `v_medicine_stock` — current stock per medicine
- `v_daily_sales` — daily sales summary
- `v_expiring_medicines` — medicines expiring within 90 days

And stored procedure:
```sql
CALL sp_low_stock(10);   -- medicines with less than 10 units
```

---

## 🚀 Production Deployment

### Using Gunicorn + Nginx

```bash
# Install gunicorn (already in requirements.txt)
gunicorn config.wsgi:application --bind 0.0.0.0:8000 --workers 3

# Or with uvicorn for async
pip install uvicorn
uvicorn config.asgi:application --host 0.0.0.0 --port 8000 --workers 3
```

**Nginx config snippet** (`/etc/nginx/sites-available/smartpharmacy`):
```nginx
server {
    listen 80;
    server_name yourdomain.com;

    location /static/ {
        alias /path/to/smart_pharmacy/staticfiles/;
    }
    location /media/ {
        alias /path/to/smart_pharmacy/media/;
    }
    location / {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

### Production Settings Checklist

```bash
# In .env
DEBUG=False
ALLOWED_HOSTS=yourdomain.com,www.yourdomain.com
SECRET_KEY=<strong-50-char-random-key>
```

---

## 🔑 User Roles

| Role | Access |
|------|--------|
| `admin` | Full access to all modules + Django admin |
| `pharmacist` | Billing, medicines, inventory, prescriptions |
| `cashier` | Billing only |
| `manager` | Reports, analytics, inventory |

---

## 📱 Key URLs Reference

| Page | URL |
|------|-----|
| Login | `/accounts/login/` |
| Dashboard | `/dashboard/` |
| POS Billing | `/billing/` |
| Bill History | `/billing/list/` |
| Medicines | `/pharmacy/medicines/` |
| Add Medicine | `/pharmacy/medicines/add/` |
| Inventory | `/inventory/` |
| Customers | `/customers/` |
| Suppliers | `/suppliers/` |
| Prescriptions | `/prescriptions/` |
| Reports | `/reports/` |
| Analytics | `/analytics/` |
| Admin | `/admin/` |

---

## 🐛 Troubleshooting

**`ModuleNotFoundError: No module named 'MySQLdb'`**
```bash
pip install mysqlclient   # or use SQLite in .env
```

**`OperationalError: FATAL: database does not exist`**
```bash
mysql -u root -p -e "CREATE DATABASE smart_pharmacy;"
```

**Static files not loading**
```bash
python manage.py collectstatic --noinput
# Make sure STATICFILES_DIRS is set in settings.py
```

**Migrations out of sync**
```bash
python manage.py migrate --run-syncdb
```

---

## 📄 License

MIT License — free to use, modify, and distribute.
