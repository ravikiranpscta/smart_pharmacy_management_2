from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from django.db.models import Sum
from django.utils import timezone
from billing.models import Bill
import json


@login_required
def analytics_view(request):
    today = timezone.now().date()
    # Monthly sales for current year
    monthly_data = []
    monthly_labels = []
    for month in range(1, 13):
        sales = Bill.objects.filter(
            created_at__year=today.year,
            created_at__month=month
        ).aggregate(total=Sum('total_amount'))['total'] or 0
        monthly_data.append(float(sales))
        import calendar
        monthly_labels.append(calendar.month_abbr[month])

    return render(request, 'analytics.html', {
        'monthly_labels': json.dumps(monthly_labels),
        'monthly_data': json.dumps(monthly_data),
    })
