from django.utils import timezone
from django.contrib.auth import get_user_model


class PharmacyMiddleware:
    """Custom middleware for pharmacy-specific logic."""

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        # Attach current time to request
        request.current_time = timezone.now()

        response = self.get_response(request)
        return response
