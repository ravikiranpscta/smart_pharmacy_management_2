from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import User


@admin.register(User)
class CustomUserAdmin(UserAdmin):
    list_display = ['username', 'email', 'first_name', 'last_name', 'role', 'is_active']
    list_filter = ['role', 'is_active', 'is_staff']
    search_fields = ['username', 'email', 'first_name', 'last_name', 'pharmacy_name']
    fieldsets = UserAdmin.fieldsets + (
        ('Pharmacy Info', {'fields': ('role', 'phone', 'pharmacy_name', 'license_number',
                                      'address', 'profile_image', 'is_verified')}),
    )
