import json
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import JsonResponse, HttpResponse
from django.db.models import Q
from django.core.paginator import Paginator
from django.utils import timezone
from .models import Bill, BillItem
from pharmacy.models import Medicine, MedicineBatch
from customers.models import Customer


@login_required
def billing_view(request):
    """Main billing page – POS interface."""
    medicines = Medicine.objects.filter(is_active=True).values(
        'id', 'name', 'strength', 'form', 'requires_prescription'
    )
    customers = Customer.objects.filter(is_active=True).values('id', 'name', 'phone')
    return render(request, 'billing.html', {
        'medicines': list(medicines),
        'customers': list(customers),
    })


@login_required
def create_bill(request):
    if request.method == 'POST':
        data = json.loads(request.body)
        items = data.get('items', [])
        if not items:
            return JsonResponse({'error': 'No items in bill'}, status=400)

        customer_id = data.get('customer_id')
        customer = None
        if customer_id:
            customer = Customer.objects.get(pk=customer_id)

        bill = Bill.objects.create(
            customer=customer,
            customer_name=data.get('customer_name', ''),
            customer_phone=data.get('customer_phone', ''),
            created_by=request.user,
            payment_method=data.get('payment_method', 'cash'),
            payment_status='paid',
            notes=data.get('notes', ''),
        )

        subtotal = 0
        gst_total = 0

        for item_data in items:
            medicine = Medicine.objects.get(pk=item_data['medicine_id'])
            batch = MedicineBatch.objects.filter(
                medicine=medicine, quantity__gt=0, expiry_date__gte=timezone.now().date()
            ).order_by('expiry_date').first()

            quantity = int(item_data['quantity'])
            unit_price = float(item_data['unit_price'])
            discount_pct = float(item_data.get('discount_percent', 0))
            gst_pct = float(item_data.get('gst_percent', 12))

            item = BillItem.objects.create(
                bill=bill,
                medicine=medicine,
                batch=batch,
                medicine_name=medicine.name,
                quantity=quantity,
                unit_price=unit_price,
                discount_percent=discount_pct,
                gst_percent=gst_pct,
            )

            # Deduct stock
            if batch and batch.quantity >= quantity:
                batch.quantity -= quantity
                batch.save()

            subtotal += item.total_price
            gst_total += item.total_price * (gst_pct / 100)

        bill.subtotal = subtotal
        bill.gst_amount = gst_total
        bill.total_amount = subtotal + gst_total - bill.discount_amount
        bill.amount_paid = float(data.get('amount_paid', bill.total_amount))
        bill.change_amount = max(0, bill.amount_paid - float(bill.total_amount))
        bill.save()

        # Update customer loyalty points
        if customer:
            customer.total_purchases += bill.total_amount
            customer.loyalty_points += int(bill.total_amount // 100)
            customer.save()

        return JsonResponse({'success': True, 'bill_id': bill.id, 'bill_number': bill.bill_number})

    return JsonResponse({'error': 'Invalid request'}, status=400)


@login_required
def bill_list(request):
    query = request.GET.get('q', '')
    bills = Bill.objects.select_related('customer', 'created_by')

    if query:
        bills = bills.filter(
            Q(bill_number__icontains=query) |
            Q(customer_name__icontains=query) |
            Q(customer_phone__icontains=query)
        )

    paginator = Paginator(bills, 20)
    page = paginator.get_page(request.GET.get('page', 1))
    return render(request, 'bill_list.html', {'bills': page, 'query': query})


@login_required
def bill_detail(request, pk):
    bill = get_object_or_404(Bill, pk=pk)
    return render(request, 'invoice.html', {'bill': bill})


@login_required
def bill_pdf(request, pk):
    """Generate PDF invoice."""
    from reportlab.lib.pagesizes import A4
    from reportlab.lib import colors
    from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
    from reportlab.lib.styles import getSampleStyleSheet
    import io

    bill = get_object_or_404(Bill, pk=pk)
    buffer = io.BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=A4)
    styles = getSampleStyleSheet()
    story = []

    story.append(Paragraph(f"INVOICE #{bill.bill_number}", styles['Title']))
    story.append(Spacer(1, 12))
    story.append(Paragraph(f"Date: {bill.created_at.strftime('%d %b %Y %I:%M %p')}", styles['Normal']))
    story.append(Paragraph(f"Customer: {bill.customer_name or 'Walk-in Customer'}", styles['Normal']))
    story.append(Spacer(1, 12))

    data = [['Medicine', 'Qty', 'Price', 'Discount', 'Total']]
    for item in bill.items.all():
        data.append([
            item.medicine_name, str(item.quantity),
            f"₹{item.unit_price}", f"{item.discount_percent}%",
            f"₹{item.total_price}"
        ])

    data.append(['', '', '', 'Subtotal', f"₹{bill.subtotal}"])
    data.append(['', '', '', 'GST', f"₹{bill.gst_amount}"])
    data.append(['', '', '', 'Total', f"₹{bill.total_amount}"])

    table = Table(data, colWidths=[200, 50, 80, 80, 80])
    table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.darkblue),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('GRID', (0, 0), (-1, -1), 0.5, colors.grey),
        ('BACKGROUND', (0, -3), (-1, -1), colors.lightgrey),
    ]))
    story.append(table)

    doc.build(story)
    buffer.seek(0)
    response = HttpResponse(buffer, content_type='application/pdf')
    response['Content-Disposition'] = f'attachment; filename="invoice_{bill.bill_number}.pdf"'
    return response


@login_required
def medicine_search_api(request):
    """AJAX endpoint to search medicines for billing."""
    q = request.GET.get('q', '')
    medicines = Medicine.objects.filter(
        is_active=True, name__icontains=q
    ).values('id', 'name', 'strength', 'form')[:10]
    return JsonResponse({'medicines': list(medicines)})


@login_required
def get_medicine_price(request, pk):
    """Get price of medicine for billing."""
    medicine = get_object_or_404(Medicine, pk=pk)
    batch = MedicineBatch.objects.filter(
        medicine=medicine, quantity__gt=0, expiry_date__gte=timezone.now().date()
    ).order_by('expiry_date').first()

    if batch:
        return JsonResponse({
            'price': float(batch.selling_price),
            'mrp': float(batch.mrp),
            'gst': float(batch.gst_percentage),
            'stock': batch.quantity,
            'batch': batch.batch_number,
        })
    return JsonResponse({'error': 'No stock available'}, status=404)
