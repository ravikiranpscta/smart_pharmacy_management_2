from django.contrib import admin
from .models import Bill, BillItem


class BillItemInline(admin.TabularInline):
    model = BillItem
    extra = 0
    readonly_fields = ['total_price']


@admin.register(Bill)
class BillAdmin(admin.ModelAdmin):
    list_display = ['bill_number', 'customer_name', 'total_amount',
                    'payment_method', 'payment_status', 'created_at']
    list_filter = ['payment_method', 'payment_status', 'created_at']
    search_fields = ['bill_number', 'customer_name', 'customer_phone']
    readonly_fields = ['bill_number', 'created_at', 'updated_at']
    inlines = [BillItemInline]
