from django.urls import path
from . import views

app_name = 'billing'

urlpatterns = [
    path('', views.billing_view, name='billing'),
    path('create/', views.create_bill, name='create_bill'),
    path('list/', views.bill_list, name='list'),
    path('<int:pk>/', views.bill_detail, name='detail'),
    path('<int:pk>/pdf/', views.bill_pdf, name='pdf'),
    path('api/medicine-search/', views.medicine_search_api, name='medicine_search'),
    path('api/medicine-price/<int:pk>/', views.get_medicine_price, name='medicine_price'),
]
