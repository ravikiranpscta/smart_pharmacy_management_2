from django.shortcuts import render
from django.contrib.auth.decorators import login_required

@login_required
def prescription_list(request):
    from .models import Prescription
    prescriptions = Prescription.objects.order_by('-created_at')
    return render(request, 'prescriptions.html', {'prescriptions': prescriptions})
