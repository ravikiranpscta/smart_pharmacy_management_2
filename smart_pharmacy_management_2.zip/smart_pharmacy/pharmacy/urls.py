from django.urls import path
from . import views

app_name = 'pharmacy'

urlpatterns = [
    path('medicines/', views.medicine_list, name='medicine_list'),
    path('medicines/add/', views.medicine_add, name='medicine_add'),
    path('medicines/<int:pk>/', views.medicine_detail, name='medicine_detail'),
    path('medicines/<int:pk>/edit/', views.medicine_edit, name='medicine_edit'),
    path('medicines/<int:pk>/delete/', views.medicine_delete, name='medicine_delete'),
    path('medicines/<int:medicine_pk>/batch/add/', views.batch_add, name='batch_add'),
    path('categories/', views.category_list, name='category_list'),
]
