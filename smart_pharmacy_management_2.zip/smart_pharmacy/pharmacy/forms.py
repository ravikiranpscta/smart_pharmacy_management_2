from django import forms
from .models import Medicine, Category, Manufacturer, MedicineBatch


class MedicineForm(forms.ModelForm):
    class Meta:
        model = Medicine
        fields = ['name', 'generic_name', 'category', 'manufacturer', 'form',
                  'strength', 'barcode', 'hsn_code', 'description', 'side_effects',
                  'storage_conditions', 'requires_prescription', 'image']

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field in self.fields.values():
            if not isinstance(field.widget, forms.CheckboxInput):
                field.widget.attrs['class'] = 'form-control'


class CategoryForm(forms.ModelForm):
    class Meta:
        model = Category
        fields = ['name', 'description']

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field in self.fields.values():
            field.widget.attrs['class'] = 'form-control'


class BatchForm(forms.ModelForm):
    class Meta:
        model = MedicineBatch
        fields = ['batch_number', 'manufacturing_date', 'expiry_date',
                  'quantity', 'purchase_price', 'selling_price', 'mrp', 'gst_percentage']
        widgets = {
            'manufacturing_date': forms.DateInput(attrs={'type': 'date'}),
            'expiry_date': forms.DateInput(attrs={'type': 'date'}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field in self.fields.values():
            field.widget.attrs['class'] = 'form-control'
