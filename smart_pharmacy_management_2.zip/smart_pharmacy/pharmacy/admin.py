from django.contrib import admin
from .models import Medicine, Category, Manufacturer, MedicineBatch


@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ['name', 'created_at']
    search_fields = ['name']


@admin.register(Manufacturer)
class ManufacturerAdmin(admin.ModelAdmin):
    list_display = ['name', 'contact_person', 'phone', 'email']
    search_fields = ['name']


@admin.register(Medicine)
class MedicineAdmin(admin.ModelAdmin):
    list_display = ['name', 'generic_name', 'category', 'form', 'strength',
                    'requires_prescription', 'is_active', 'current_stock']
    list_filter = ['category', 'form', 'requires_prescription', 'is_active']
    search_fields = ['name', 'generic_name', 'barcode']
    readonly_fields = ['created_at', 'updated_at']


@admin.register(MedicineBatch)
class BatchAdmin(admin.ModelAdmin):
    list_display = ['medicine', 'batch_number', 'quantity', 'expiry_date',
                    'selling_price', 'is_expired']
    list_filter = ['expiry_date']
    search_fields = ['medicine__name', 'batch_number']
