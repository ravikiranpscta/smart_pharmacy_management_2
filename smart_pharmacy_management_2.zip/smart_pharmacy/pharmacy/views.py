from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.db.models import Q
from django.core.paginator import Paginator
from .models import Medicine, Category, Manufacturer, MedicineBatch
from .forms import MedicineForm, CategoryForm, BatchForm


@login_required
def medicine_list(request):
    query = request.GET.get('q', '')
    category_id = request.GET.get('category', '')
    medicines = Medicine.objects.filter(is_active=True).select_related('category', 'manufacturer')

    if query:
        medicines = medicines.filter(
            Q(name__icontains=query) |
            Q(generic_name__icontains=query) |
            Q(barcode__icontains=query)
        )
    if category_id:
        medicines = medicines.filter(category_id=category_id)

    paginator = Paginator(medicines, 20)
    page = paginator.get_page(request.GET.get('page', 1))

    return render(request, 'medicine.html', {
        'medicines': page,
        'categories': Category.objects.all(),
        'query': query,
    })


@login_required
def medicine_add(request):
    form = MedicineForm(request.POST or None, request.FILES or None)
    if request.method == 'POST' and form.is_valid():
        medicine = form.save()
        messages.success(request, f'Medicine "{medicine.name}" added successfully!')
        return redirect('pharmacy:medicine_list')
    return render(request, 'medicine_form.html', {'form': form, 'title': 'Add Medicine'})


@login_required
def medicine_edit(request, pk):
    medicine = get_object_or_404(Medicine, pk=pk)
    form = MedicineForm(request.POST or None, request.FILES or None, instance=medicine)
    if request.method == 'POST' and form.is_valid():
        form.save()
        messages.success(request, 'Medicine updated successfully!')
        return redirect('pharmacy:medicine_list')
    return render(request, 'medicine_form.html', {'form': form, 'title': 'Edit Medicine'})


@login_required
def medicine_delete(request, pk):
    medicine = get_object_or_404(Medicine, pk=pk)
    if request.method == 'POST':
        medicine.is_active = False
        medicine.save()
        messages.success(request, 'Medicine removed successfully!')
        return redirect('pharmacy:medicine_list')
    return render(request, 'confirm_delete.html', {'object': medicine})


@login_required
def medicine_detail(request, pk):
    medicine = get_object_or_404(Medicine, pk=pk)
    batches = medicine.batches.order_by('expiry_date')
    return render(request, 'medicine_detail.html', {'medicine': medicine, 'batches': batches})


@login_required
def category_list(request):
    categories = Category.objects.all()
    return render(request, 'category_list.html', {'categories': categories})


@login_required
def batch_add(request, medicine_pk):
    medicine = get_object_or_404(Medicine, pk=medicine_pk)
    form = BatchForm(request.POST or None)
    if request.method == 'POST' and form.is_valid():
        batch = form.save(commit=False)
        batch.medicine = medicine
        batch.save()
        messages.success(request, f'Batch added for {medicine.name}!')
        return redirect('pharmacy:medicine_detail', pk=medicine_pk)
    return render(request, 'batch_form.html', {'form': form, 'medicine': medicine})
