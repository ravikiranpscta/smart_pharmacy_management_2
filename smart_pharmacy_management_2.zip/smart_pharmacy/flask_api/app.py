"""
Flask AI API for Smart Pharmacy
Provides: recommendation, symptom checker, drug interaction checker
Run separately: python flask_api/app.py
"""
from flask import Flask, request, jsonify
from flask_cors import CORS

app = Flask(__name__)
CORS(app)


@app.route('/health', methods=['GET'])
def health():
    return jsonify({'status': 'ok', 'service': 'SmartRx AI API'})


@app.route('/api/recommend', methods=['POST'])
def recommend():
    """Recommend medicines based on symptoms."""
    data = request.get_json()
    symptoms = data.get('symptoms', [])
    # Placeholder — wire up your ML model here
    recommendations = [
        {'medicine': 'Paracetamol 500mg', 'reason': 'Fever & pain relief', 'confidence': 0.92},
        {'medicine': 'Ibuprofen 400mg', 'reason': 'Anti-inflammatory', 'confidence': 0.78},
    ]
    return jsonify({'symptoms': symptoms, 'recommendations': recommendations})


@app.route('/api/interaction-check', methods=['POST'])
def interaction_check():
    """Check drug-drug interactions."""
    data = request.get_json()
    medicines = data.get('medicines', [])
    # Placeholder interaction logic
    interactions = []
    if len(medicines) >= 2:
        interactions.append({
            'drug_a': medicines[0],
            'drug_b': medicines[1],
            'severity': 'moderate',
            'description': 'Monitor patient when co-administered.',
        })
    return jsonify({'medicines': medicines, 'interactions': interactions})


@app.route('/api/dosage', methods=['POST'])
def dosage():
    """Get dosage guidance for a medicine."""
    data = request.get_json()
    medicine = data.get('medicine', '')
    age = data.get('age', 30)
    weight = data.get('weight', 70)
    # Placeholder dosage logic
    return jsonify({
        'medicine': medicine,
        'recommended_dose': '500mg',
        'frequency': '3 times daily',
        'notes': f'Adjust dose for patient age {age}, weight {weight}kg.',
    })


@app.route('/api/chatbot', methods=['POST'])
def chatbot():
    """Simple pharmacy chatbot endpoint."""
    data = request.get_json()
    message = data.get('message', '').lower()

    responses = {
        'paracetamol': 'Paracetamol is used for fever and mild-to-moderate pain. Usual adult dose: 500mg–1g every 4–6 hours.',
        'ibuprofen': 'Ibuprofen is an NSAID used for pain, fever, and inflammation. Take with food.',
        'fever': 'For fever, Paracetamol or Ibuprofen are commonly recommended. Stay hydrated.',
        'headache': 'For headache, rest and Paracetamol 500mg usually help. If persistent, consult a doctor.',
    }

    for keyword, response in responses.items():
        if keyword in message:
            return jsonify({'reply': response})

    return jsonify({'reply': 'I can help with medicine queries. Please ask about a specific medicine or symptom.'})


if __name__ == '__main__':
    app.run(debug=True, port=5000)
