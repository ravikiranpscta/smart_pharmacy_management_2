@echo off
echo ================================================
echo   Smart Pharmacy Management - Setup Script
echo ================================================
echo.

:: Check Python
python --version >nul 2>&1
if errorlevel 1 (
    echo ERROR: Python is not installed or not in PATH.
    echo Please install Python 3.10+ from https://python.org
    echo Make sure to check "Add Python to PATH" during install.
    pause
    exit /b 1
)

echo [1/6] Creating virtual environment...
python -m venv venv
if errorlevel 1 (
    echo ERROR: Failed to create virtual environment.
    pause
    exit /b 1
)

echo [2/6] Activating virtual environment...
call venv\Scripts\activate.bat

echo [3/6] Installing required packages...
pip install --quiet django==4.2.7 djangorestframework django-crispy-forms crispy-bootstrap5 django-environ Pillow reportlab openpyxl whitenoise django-extensions
if errorlevel 1 (
    echo ERROR: Package installation failed.
    pause
    exit /b 1
)

echo [4/6] Running database migrations...
python manage.py migrate --run-syncdb
if errorlevel 1 (
    echo ERROR: Migration failed.
    pause
    exit /b 1
)

echo [5/6] Collecting static files...
python manage.py collectstatic --noinput

echo [6/6] Creating admin user...
echo.
echo Please enter details for the admin account:
python manage.py createsuperuser

echo.
echo ================================================
echo   Setup Complete!
echo ================================================
echo.
echo   Run the server anytime with:
echo     start_server.bat
echo.
echo   OR manually:
echo     venv\Scripts\activate
echo     python manage.py runserver
echo.
echo   Then open: http://127.0.0.1:8000
echo.
pause
