@echo off
echo ================================================
echo   Smart Pharmacy Management - Starting Server
echo ================================================
echo.

:: Activate venv
call venv\Scripts\activate.bat 2>nul
if errorlevel 1 (
    echo Virtual environment not found.
    echo Please run setup.bat first!
    pause
    exit /b 1
)

echo Starting Django server...
echo.
echo   Dashboard : http://127.0.0.1:8000/dashboard/
echo   Billing   : http://127.0.0.1:8000/billing/
echo   Admin     : http://127.0.0.1:8000/admin/
echo.
echo Press CTRL+C to stop the server.
echo.

:: Open browser automatically after 2 seconds
start /min cmd /c "timeout /t 2 >nul && start http://127.0.0.1:8000/dashboard/"

python manage.py runserver

pause
