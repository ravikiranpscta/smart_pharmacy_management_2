from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from django.db.models import Sum, Count
from django.utils import timezone
from datetime import timedelta
from billing.models import Bill, BillItem
from pharmacy.models import Medicine


@login_required
def reports_view(request):
    today = timezone.now().date()
    period = request.GET.get('period', 'monthly')

    if period == 'daily':
        start_date = today
    elif period == 'weekly':
        start_date = today - timedelta(days=7)
    elif period == 'yearly':
        start_date = today.replace(month=1, day=1)
    else:  # monthly
        start_date = today.replace(day=1)

    bills = Bill.objects.filter(created_at__date__gte=start_date)
    total_sales = bills.aggregate(total=Sum('total_amount'))['total'] or 0
    total_bills = bills.count()
    total_gst = bills.aggregate(total=Sum('gst_amount'))['total'] or 0

    # Top selling medicines
    top_medicines = BillItem.objects.filter(
        bill__created_at__date__gte=start_date
    ).values('medicine_name').annotate(
        total_qty=Sum('quantity'),
        total_revenue=Sum('total_price')
    ).order_by('-total_revenue')[:10]

    return render(request, 'reports.html', {
        'total_sales': total_sales,
        'total_bills': total_bills,
        'total_gst': total_gst,
        'top_medicines': top_medicines,
        'period': period,
        'start_date': start_date,
    })
