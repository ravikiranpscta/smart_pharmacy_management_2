from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from django.db.models import Sum, Count, Q
from django.utils import timezone
from datetime import timedelta
import json


@login_required
def index(request):
    today = timezone.now().date()
    week_ago = today - timedelta(days=7)
    month_start = today.replace(day=1)

    from billing.models import Bill
    from pharmacy.models import Medicine, MedicineBatch
    from customers.models import Customer
    from suppliers.models import Supplier

    # Today's stats
    today_bills = Bill.objects.filter(created_at__date=today)
    today_sales = today_bills.aggregate(total=Sum('total_amount'))['total'] or 0
    today_bill_count = today_bills.count()

    # Monthly stats
    month_bills = Bill.objects.filter(created_at__date__gte=month_start)
    month_sales = month_bills.aggregate(total=Sum('total_amount'))['total'] or 0

    # Inventory alerts
    expiring_soon = MedicineBatch.objects.filter(
        expiry_date__lte=today + timedelta(days=90),
        expiry_date__gte=today,
        quantity__gt=0
    ).count()

    expired = MedicineBatch.objects.filter(
        expiry_date__lt=today, quantity__gt=0
    ).count()

    low_stock_medicines = Medicine.objects.filter(is_active=True)
    low_stock_count = sum(1 for m in low_stock_medicines if m.is_low_stock)

    # Recent bills
    recent_bills = Bill.objects.select_related('customer').order_by('-created_at')[:5]

    # Sales chart data (last 7 days)
    chart_labels = []
    chart_data = []
    for i in range(6, -1, -1):
        day = today - timedelta(days=i)
        sales = Bill.objects.filter(created_at__date=day).aggregate(
            total=Sum('total_amount'))['total'] or 0
        chart_labels.append(day.strftime('%d %b'))
        chart_data.append(float(sales))

    context = {
        'today_sales': today_sales,
        'today_bill_count': today_bill_count,
        'month_sales': month_sales,
        'total_medicines': Medicine.objects.filter(is_active=True).count(),
        'total_customers': Customer.objects.filter(is_active=True).count(),
        'total_suppliers': Supplier.objects.filter(is_active=True).count(),
        'expiring_soon': expiring_soon,
        'expired': expired,
        'low_stock_count': low_stock_count,
        'recent_bills': recent_bills,
        'chart_labels': json.dumps(chart_labels),
        'chart_data': json.dumps(chart_data),
    }
    return render(request, 'dashboard.html', context)
